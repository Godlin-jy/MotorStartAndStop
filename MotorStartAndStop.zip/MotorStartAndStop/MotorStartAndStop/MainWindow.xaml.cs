﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Threading.Tasks;
using S7.Net;

namespace MotorStartAndStop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Plc plc;
        private DispatcherTimer timer;
        private bool motorState;
        public MainWindow()
        {
            InitializeComponent();
            Task.Run(() => ConnectToPLC());

            //创建定时器
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(5);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void ConnectToPLC()
        {
            try
            {
                plc = new Plc(CpuType.S71500, "192.168.31.34", 0, 1);
                plc.Open();
            }
            catch (Exception ex)
            {
                // 在UI线程更新状态信息
                Dispatcher.Invoke(() =>
                {
                    state.Text = "Error: " + ex.Message;
                });
            }
        }

        private async void Timer_Tick(object? sender, EventArgs e)
        {
            CurrentDateTime.Text = DateTime.Now.ToString("G");

            try
            {
                var isConnected = await Task.Run(() => ReadFromPLC());
                if (isConnected)
                {
                    state.Text = "Connected";
                    if (motorState == false)
                    {
                        Motor.Fill = Brushes.LightGray;
                    }
                    else if (motorState == true)
                    {
                        Motor.Fill = Brushes.Green;
                    }
                }
                else
                {
                    state.Text = "NotConnected";
                }
            }
            catch (Exception ex)
            {
                state.Text = "Error: " + ex.Message;
            }
            if (motorState == false)
                StartOrStopButton.Content = "Start";
            else if (motorState == true)
                StartOrStopButton.Content = "Stop";

            

            if(motorState == false)
            {
                Motor.Fill = Brushes.LightGray;
            }
            else if(motorState == true)
            {
                Motor.Fill = Brushes.Green;
            }
        }
        
        private bool ReadFromPLC()
        {
            if (plc.IsConnected)
            {
                motorState = (bool)plc.Read("M0.3");
                return true;
            }
            else
            {
                return false;
            }
        }

        //画面拖动
        private void Window_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            DragMove();
        }

        //关闭按钮
        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        //Methond1的StartOrStopButton按钮事件
        private void StartOrStopButton_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                plc.Write("M0.0", 1);
            }
            catch (Exception ex)
            {
                state.Text = "Error: " + ex.Message;
            }

        }

        //Method2的StartButton按钮事件
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                plc.Write("M0.1", 1);
            }
            catch(Exception ex)
            {
                state.Text = "Error: " + ex.Message;
            }
        }

        //Method2的StopButton按钮事件
        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                plc.Write("M0.2", 1);
            }
            catch (Exception ex)
            {
                state.Text = "Error: " + ex.Message;
            }
        }

        
    }
}